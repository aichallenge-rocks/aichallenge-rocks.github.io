var rotations = {
    clockwise: 0,
    counterclockwise: 1
};

module.exports = rotations;