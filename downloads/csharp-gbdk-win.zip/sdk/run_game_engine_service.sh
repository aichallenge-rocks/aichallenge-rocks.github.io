#! /bin/bash
nodejs bin/gameEngineService.js
