﻿using SDK;

namespace Runner
{
    internal interface IBot
    {
        string GetMove(Board board, Color color);
    }
}
