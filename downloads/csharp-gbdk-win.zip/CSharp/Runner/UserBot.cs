﻿using System;
using System.Linq;
using SDK;

namespace Runner
{
    internal class UserBot : IBot
    {
        public string GetMove(Board board, Color color)
        {
            var moves = board.GetAvailableMoves(color).ToArray();
            var random = new Random();
            var index = random.Next(moves.Count());
            var move = moves[index].ToString();
            Console.WriteLine("[UserBot] color: {0} move: {1}", color, move);
            return move;
        }
    }
}
