﻿using System.Threading;
using Nancy.Hosting.Self;
using Runner.Infrastructure;
using System;
using System.Net.Http;
using System.Text;
using System.Web.Script.Serialization;

namespace Runner
{
    internal class Program
    {
        private static ManualResetEvent quitEvent;

        static void Main()
        {
            using (var host = new NancyHost(
                 new HostConfiguration() { UrlReservations = new UrlReservations { CreateAutomatically = true }},
                 new Uri(String.Format("http://localhost:{0}", RunnerConfig.Port))))
            {
                host.Start();
                Console.WriteLine("Listening on port " + RunnerConfig.Port);

                StartGame();

                quitEvent = new ManualResetEvent(false);
                quitEvent.WaitOne();

                quitEvent.Dispose();
            }
        }

        private static void StartGame()
        {
            var client = new HttpClient();
            if (RunnerConfig.IsInLocalMode)
            {
                var bots = new []
                {
                    new
                    {
                        color = SDK.Color.White,
                        userId = RunnerConfig.UserBotColor == SDK.Color.White ? 1 : 2
                    },
                    new {
                        color = SDK.Color.Red,
                        userId = RunnerConfig.UserBotColor == SDK.Color.Red ? 1 : 2
                    }
                };

                var result = client.PostAsync(GameEngineConfig.StartGameUrl, BuildJsonContent(bots)).Result;

                foreach (var bot in bots)
                {
                    client.PostAsync(GameEngineConfig.BotReadyUrl, BuildJsonContent(bot));
                }
            }
            else
            {
                client.PostAsync(GameEngineConfig.BotReadyUrl, null);
            }
        }

        private static HttpContent BuildJsonContent(object value)
        {
            var json = new JavaScriptSerializer().Serialize(value);
            return new StringContent(json, Encoding.UTF8, "application/json");
        }
    }
}
