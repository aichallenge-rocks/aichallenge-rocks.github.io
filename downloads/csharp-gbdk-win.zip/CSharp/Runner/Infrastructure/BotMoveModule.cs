﻿using Nancy;
using Nancy.ModelBinding;

namespace Runner.Infrastructure
{
    public class BotMoveModule : NancyModule
    {
        public BotMoveModule(BotRunner botRunner)
        {
            Post["/move"] = _ => botRunner.GetMove(this.Bind<GameState>());
        }
    }
}
