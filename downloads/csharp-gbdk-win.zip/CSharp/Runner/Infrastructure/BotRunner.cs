﻿using System;
using System.Diagnostics;
using SDK;

namespace Runner.Infrastructure
{
    public class BotRunner
    {
        private readonly IBot[] bots;
        private int currentTurn;
        private readonly int botCount;
        private Stopwatch profiler;
        private int maxMoveTime;

        public BotRunner()
        {
            bots = new IBot[]
            {
                new UserBot(),
                new DefaultBot()
            };

            currentTurn = RunnerConfig.IsInLocalMode && RunnerConfig.UserBotColor == Color.Red ? 1 : 0;
            botCount = RunnerConfig.IsInLocalMode ? bots.Length : 1;
            maxMoveTime = RunnerConfig.IsInLocalMode ? Int32.MaxValue : 4;
            profiler = new Stopwatch();
        }

        public string GetMove(GameState gameState)
        {
            Console.WriteLine(gameState.Board);

            var board = Utils.CreateBoardFromPosition(gameState.Board);
            profiler.Restart();
            var move = bots[currentTurn].GetMove(board, (Color)gameState.Color);
            profiler.Stop();

            if (profiler.Elapsed.TotalSeconds > maxMoveTime)
            {
                Console.WriteLine("[BOT MOVE TIMEOUT]");
                throw new Exception("[BOT MOVE TIMEOUT]");
            }

            currentTurn = (currentTurn + 1) % botCount;
            return move;
        }
    }
}
