﻿using System;
using System.Text.RegularExpressions;
using SDK;

namespace Runner.Infrastructure
{
    internal static class RunnerConfig
    {
        private static bool isInLocalMode = new Regex("^1|true$", RegexOptions.IgnoreCase)
                                            .IsMatch(Environment.GetEnvironmentVariable("IS_IN_LOCAL_MODE") ?? "true");
        private static UInt16 port = UInt16.Parse(Environment.GetEnvironmentVariable("PORT") ?? "8081");

        public static bool IsInLocalMode
        {
            get {  return isInLocalMode ; }
        }

        public static UInt16 Port
        {
            get { return port; }
        }

        public const Color UserBotColor = Color.White;
    }

    internal static class GameEngineConfig
    {
        private static UInt16 port = UInt16.Parse(Environment.GetEnvironmentVariable("GAME_ENGINE_PORT") ?? "8080");
        private static string hostname = Environment.GetEnvironmentVariable("GAME_ENGINE_HOSTNAME") ?? "localhost";

        public static string StartGameUrl
        {
            get
            {
                return String.Format("http://{0}:{1}/api/game/start", hostname, port);
            }
        }

        public static string BotReadyUrl
        {
            get
            {
                return String.Format("http://{0}:{1}/api/bot/ready", hostname, port); 
            }
        }
    }
}
