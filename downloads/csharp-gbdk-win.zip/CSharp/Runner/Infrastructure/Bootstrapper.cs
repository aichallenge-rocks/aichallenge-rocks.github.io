﻿using Nancy;
using Nancy.Bootstrapper;
using Nancy.TinyIoc;

namespace Runner.Infrastructure
{
    public class Bootstrapper : DefaultNancyBootstrapper
    {
        protected override void ApplicationStartup(TinyIoCContainer container, IPipelines pipelines)
        {
            container.Register<BotRunner>().AsSingleton();
        }
    }
}
