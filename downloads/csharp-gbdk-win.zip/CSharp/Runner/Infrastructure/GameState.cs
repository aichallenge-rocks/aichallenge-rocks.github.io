﻿namespace Runner.Infrastructure
{
    public class GameState
    {
        public string Board { get; set; }
        public int Color { get; set; }
    }
}
