﻿using SDK;
using SDK.Figures;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Runner
{
    internal class DefaultBot : IBot
    {

        public string GetMove(SDK.Board board, Color color)
        {
            var bestMoves = new List<IMove>();
            var maxScore = -int.MaxValue;
            var position = board.Serialize();
            foreach (var move in board.GetAvailableMoves(color))
            {
                var score = GetMoveScore(position, move, color);
                if (score > maxScore)
                {
                    bestMoves.Clear();
                    maxScore = score;
                } 
                if (score == maxScore)
                {
                    bestMoves.Add(move);
                }
            }
            return LogMove(ChooseRandom(bestMoves), color).ToString();
        }

        private int GetMoveScore(string position, IMove move, Color color)
        {
            var opponentColor = (color == Color.Red ? Color.White : Color.Red);
            var newBoard = Utils.CreateBoardFromPosition(position);
            newBoard.MakeMove(move, color);

            var opponentKilledFigure = newBoard.GetFigureToBeKilledBySphinx(color);
            var myKilledFigure = newBoard.GetFigureToBeKilledBySphinx(opponentColor);

            var score = GetKilledFigureScore(opponentKilledFigure, color) + GetKilledFigureScore(myKilledFigure, color);
            return score;
        }

        private int GetKilledFigureScore(Figure figure, Color myColor)
        {
            if (figure == null) return 0;
            var sign = (figure.Color == myColor ? -1 : +1);
            return figure is Pharaoh ? sign * 1000 : sign * 10;
        }

        private IMove LogMove(IMove move, Color color)
        {
            Console.WriteLine("[DefaultBot] color: {0} move: {1}", color, move);
            return move;
        }

        private IMove ChooseRandom(List<IMove> moves)
        {
            var random = new Random();
            var index = random.Next(moves.Count());
            return moves[index];
        }
    }
}
