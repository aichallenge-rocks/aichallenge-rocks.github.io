﻿using System;

namespace SDK
{
    public interface IMove
    {
    }
}
