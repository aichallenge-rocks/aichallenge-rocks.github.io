﻿using System;

namespace SDK
{
    public class Rotate : IMove
    {
        public readonly BoardCoordinate Origin;
        public readonly Rotation Rotation;

        public Rotate(BoardCoordinate origin, Rotation rotation)
        {
            Origin = origin;
            Rotation = rotation;
        }

        public override string ToString()
        {
            return String.Empty + Origin + (Rotation == SDK.Rotation.Clockwise ? "+1" : "-1");
        }
    }
}
