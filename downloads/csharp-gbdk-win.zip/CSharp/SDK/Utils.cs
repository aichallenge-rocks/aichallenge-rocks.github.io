﻿using System;
using System.Text.RegularExpressions;
using SDK.Figures;

namespace SDK
{
    public static class Utils
    {
        // Move to Board.Parse?
        public static Board CreateBoardFromPosition(string position)
        {
            var board = new Board();
            var figures = new Regex("\\s").Replace(position, String.Empty).Split(',');
            foreach (var figure in figures)
            {
                var bc = BoardCoordinate.Parse(figure.Substring(2, 2));
                board.GetSquare(bc).Figure = FigureFactory.Get(figure.Substring(0, 2));
            }
            return board;
        }
    }
}
