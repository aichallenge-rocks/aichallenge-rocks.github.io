﻿using System;
using SDK.Figures;

namespace SDK
{
    public class Square
    {
        public Figure Figure;
        public Color Color;

        public Square(Color color)
        {
            Color = color;
        }
    }
}
