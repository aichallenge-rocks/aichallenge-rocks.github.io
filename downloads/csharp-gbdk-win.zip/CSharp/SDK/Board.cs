﻿using System;

namespace SDK
{
    public class Board
    {
        private const int DefaultBoardWidth = 10, DefaultBoardHeight = 8;

        private Square[,] squares;
        public readonly int Width, Height;

        public Board()
        {
            Height = DefaultBoardHeight;
            Width = DefaultBoardWidth;
            squares = new Square[Height, Width];

            for (var y = 0; y < Height; y++)
            {
                for (var x = 0; x < Width; x++)
                {
                    Color squareColor = Color.Neutral;
                    if (x == 0 || (x == 8 && (y == 0 || y == 7)))
                        squareColor = Color.Red;
                    else if (x == 9 || (x == 1 && (y == 0 || y == 7)))
                        squareColor = Color.White;
                    squares[y, x] = new Square(squareColor);
                }
            }
        }

        public Square GetSquare(BoardCoordinate bc)
        {
            return squares[bc.Y, bc.X];
        }

        public bool IsOutOfBounds (BoardCoordinate bc)
        {
            return bc.X < 0 || bc.X >= Width || bc.Y < 0 || bc.Y >= Height;
        }
    }
}
