﻿using System;

namespace SDK
{
    public struct BoardCoordinate
    {
        public int X, Y;

        public BoardCoordinate(int x, int y)
        {
            X = x;
            Y = y;
        }

        public override int GetHashCode()
        {
            return X | Y;
        }

        public override bool Equals(object obj)
        {
            if (!(obj is BoardCoordinate))
                return false;

            var bc = (BoardCoordinate)obj;

            return X == bc.X && Y == bc.Y;
        }

        public static BoardCoordinate Get(int x, int y)
        {
            return new BoardCoordinate(x, y);
        }

        public override string ToString()
        {
            return String.Empty + Y + X;
        }

        public static BoardCoordinate Parse (string bc)
        {
            if (bc.Length != 2)
                throw new ArgumentException();

            var y = Convert.ToInt32(bc.Substring(0, 1));
            var x = Convert.ToInt32(bc.Substring(1, 1));

            return new BoardCoordinate(x, y);
        }
    }
}
