﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDK.Figures
{
    public class Scarab : Figure
    {
        public Scarab(Orientation orientation, Color color)
            : base(orientation, color) { }

        public override bool DoesReflectLaserFrom(Orientation orientation)
        {
            return true;
        }

        public override bool WillBeKilledByLaserFrom(Orientation orientation)
        {
            return false;
        }

        public override Orientation GetOrientationOfReflectedLaserFrom(Orientation orientation)
        {
            return (Orientation == orientation || Orientation == orientation.Reverse())
                ? orientation.Clockwise()
                : orientation.Counterclockwise();
        }

        public override string ToString()
        {
            return (Color == SDK.Color.White ? "C" : "c") 
                + (int)(Orientation == Orientation.North || Orientation == Orientation.South ? Orientation.North : Orientation.East);
        }
    }
}
