﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDK.Figures
{
    public abstract class Figure
    {
        public Orientation Orientation;
        public Color Color;

        public Figure(Orientation orientation, Color color)
        {
            Orientation = orientation;
            Color = color;
        }

        public override int GetHashCode()
        {
            return (int)Orientation | (int)Color;
        }

        public override bool Equals(object obj)
        {
            if (this.GetType() != obj.GetType())
                return false;

            var figure = (Figure)obj;

            return Orientation == figure.Orientation && Color == figure.Color;
        }

        public void Rotate(Rotation rotation)
        {
            Orientation = rotation == Rotation.Clockwise ? Orientation.Clockwise() : Orientation.Counterclockwise();
        }

        public abstract bool DoesReflectLaserFrom(Orientation orientation);
        public abstract bool WillBeKilledByLaserFrom(Orientation orientation);
        public abstract Orientation GetOrientationOfReflectedLaserFrom(Orientation orientation);
    }
}
