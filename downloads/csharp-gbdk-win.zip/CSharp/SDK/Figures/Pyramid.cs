﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDK.Figures
{
    public class Pyramid : Figure
    {
        public Pyramid(Orientation orientation, Color color)
            : base(orientation, color) { }

        public override bool DoesReflectLaserFrom(Orientation orientation)
        {
            return Orientation == orientation.Reverse() || Orientation.Clockwise() == orientation;
        }

        public override bool WillBeKilledByLaserFrom(Orientation orientation)
        {
            return Orientation != orientation.Reverse() && Orientation.Clockwise() != orientation;
        }

        public override Orientation GetOrientationOfReflectedLaserFrom(Orientation orientation)
        {
            if (Orientation == orientation.Reverse())
                return Orientation.Counterclockwise();

            if (Orientation == orientation.Counterclockwise())
                return Orientation;

            throw new InvalidOperationException();
        }

        public override string ToString()
        {
            return (Color == SDK.Color.White ? "P" : "p") + (int)Orientation;
        }
    }
}
