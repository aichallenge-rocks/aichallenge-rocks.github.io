﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDK.Figures
{
    public class Anubis : Figure
    {
        public Anubis(Orientation orientation, Color color)
            : base(orientation, color) { }
            
        public override bool DoesReflectLaserFrom(Orientation orientation)
        {
            return false;
        }
        
        public override bool WillBeKilledByLaserFrom(Orientation orientation)
        {
            return Orientation != orientation.Reverse();
        }

        public override Orientation GetOrientationOfReflectedLaserFrom(Orientation orientation)
        {
            throw new InvalidOperationException();
        }

        public override string ToString()
        {
            return (Color == Color.White ? "A" : "a") + (int)Orientation;
        }
    }
}
