﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDK.Figures
{
    public static class FigureFactory
    {
        public static Figure Get(string figure)
        {
            var color = Char.IsUpper(figure[0]) ? Color.White : Color.Red;

            if (Char.ToLower(figure[1]) == 'h')
            {
                return new Pharaoh(Orientation.North, color);
            }

            var orientation = (Orientation)Convert.ToInt32(figure.Substring(1, 1));
            switch (Char.ToLower(figure[0]))
            {
                case 'p':
                    return new Pyramid(orientation, color);
                case 'c':
                    return new Scarab(orientation, color);
                case 's':
                    return new Sphinx(orientation, color);
                case 'a':
                    return new Anubis(orientation, color);
                default:
                    throw new ArgumentException();
            }
        }
    }
}
