﻿using System;
using SDK.Figures;
using System.Linq;
using System.Collections.Generic;

namespace SDK
{
    public static class OrientationExtensions
    {
        public static Orientation Reverse(this Orientation orientation)
        {
            switch (orientation)
            {
                case Orientation.North:
                    return Orientation.South;
                case Orientation.East:
                    return Orientation.West;
                case Orientation.South:
                    return Orientation.North;
                case Orientation.West:
                    return Orientation.East;
                default:
                    throw new ArgumentException();
            }
        }

        public static Orientation Clockwise(this Orientation orientation)
        {
            switch (orientation)
            {
                case Orientation.North:
                    return Orientation.East;
                case Orientation.East:
                    return Orientation.South;
                case Orientation.South:
                    return Orientation.West;
                case Orientation.West:
                    return Orientation.North;
                default:
                    throw new ArgumentException();
            }
        }

        public static Orientation Counterclockwise(this Orientation orientation)
        {
            switch (orientation)
            {
                case Orientation.North:
                    return Orientation.West;
                case Orientation.East:
                    return Orientation.North;
                case Orientation.South:
                    return Orientation.East;
                case Orientation.West:
                    return Orientation.South;
                default:
                    throw new ArgumentException();
            }
        }
    }

    public static class BoardCoordinateExtensions
    {
        public static BoardCoordinate Add (this BoardCoordinate bc, Orientation orientation)
        {
            var clone = bc;
            switch (orientation)
            {
                case Orientation.North:
                    clone.Y--;
                    break;
                case Orientation.East:
                    clone.X++;
                    break;
                case Orientation.South:
                    clone.Y++;
                    break;
                case Orientation.West:
                    clone.X--;
                    break;
            }
            return clone;
        }
    }

    public static class SquareExtensions
    {
        public static bool IsColorAvailable(this Square square, Color color)
        {
            return square.Color == Color.Neutral || square.Color == color;
        }
    }

    public static class BoardExtensions
    {
        public static string Serialize(this Board board)
        {
            var notation = new List<string>();
            for (var y = 0; y < board.Height; y++)
            {
                for (var x = 0; x < board.Width; x++)
                {
                    var bc = BoardCoordinate.Get(x, y);
                    var figure = board.GetSquare(bc).Figure;

                    if (figure != null)
                        notation.Add(String.Empty + figure + BoardCoordinate.Get(x, y));
                }
            }

            return String.Join(",", notation);
        }

        public static BoardCoordinate GetFigureCoordinates(this Board board, Figure figure)
        {
            var xs = Enumerable.Range(0, board.Width);
            var ys = Enumerable.Range(0, board.Height);

            foreach (var y in ys)
            {
                foreach (var x in xs)
                {
                    var bc = BoardCoordinate.Get(x, y);
                    if (board.GetSquare(bc).Figure == figure)
                        return bc;
                }
            }

            throw new ArgumentException();
        }

        public static Figure GetFigureToBeKilledByLaser(this Board board, BoardCoordinate bc, Orientation orientation)
        {
            if (board.IsOutOfBounds(bc))
                return null;

            var figure = board.GetSquare(bc).Figure;
            if (figure != null)
            {
                if (figure.DoesReflectLaserFrom(orientation))
                {
                    var newOrientation = figure.GetOrientationOfReflectedLaserFrom(orientation);
                    return board.GetFigureToBeKilledByLaser(bc.Add(newOrientation), newOrientation);
                }
                if (figure.WillBeKilledByLaserFrom(orientation))
                    return figure;
                return null;
            }

            return board.GetFigureToBeKilledByLaser(bc.Add(orientation), orientation);
        }
        
        public static Figure GetFigureToBeKilledBySphinx(this Board board, Color color)
        {
            var bc = (color == Color.White) ? BoardCoordinate.Get(9, 7) : BoardCoordinate.Get(0, 0);
            var figure = board.GetSquare(bc).Figure;

            if (figure is Sphinx && figure.Color == color) {
                return board.GetFigureToBeKilledByLaser(bc.Add(figure.Orientation), figure.Orientation);
            }

            return null;
        }

        public static bool IsMoveValid(this Board board, IMove move, Color color)
        {
            Figure figure;
            if (move is Rotate)
            {
                var rotate = (Rotate)move;

                if (board.IsOutOfBounds(rotate.Origin)) return false;

                figure = board.GetSquare(rotate.Origin).Figure;
                if (figure.Color != color) return false;
                var rot = figure.ToString() + (rotate.Rotation == Rotation.Clockwise ? "+1" : "-1");
                if ((rot =="S1+1") || (rot == "S4-1") || (rot =="s3+1") || (rot == "s2-1")) 
                    return false;

                return true;
            }
            var shift = (Shift)move;

            if (board.IsOutOfBounds(shift.Origin) || board.IsOutOfBounds(shift.Destination)) return false;

            var origin = board.GetSquare(shift.Origin);
            figure = origin.Figure;

            if (figure == null) return false;

            if (figure.Color != color || figure is Sphinx) return false;

            if (Math.Abs(shift.Origin.X - shift.Destination.X) > 1 || Math.Abs(shift.Origin.Y - shift.Destination.Y) > 1 || shift.Origin.Equals(shift.Destination))
                    return false;

            var destination = board.GetSquare(shift.Destination);

            if (!destination.IsColorAvailable(figure.Color)) return false;

            var destFigure = destination.Figure;

            if (destFigure != null)
                return figure is Scarab && (destFigure is Pyramid || destFigure is Anubis) && origin.IsColorAvailable(destFigure.Color);

            return true;
        }

        public static IEnumerable<IMove> GetAvailableMoves(this Board board, Color color)
        {
            IMove move;
            var rotations = new[] {Rotation.Clockwise, Rotation.Counterclockwise};

            for (var y = 0; y < board.Height; y++)
            {
                for (var x = 0; x < board.Width; x++)
                {
                    var origin = BoardCoordinate.Get(x, y);
                    var figure = board.GetSquare(origin).Figure;
                    if (figure == null || figure.Color != color)
                        continue;

                    foreach (var rot in rotations)
                    {
                        move = new Rotate(origin, rot);
                        if (board.IsMoveValid(move, color))
                            yield return move;
                    }
                    
                    for (var dx = -1; dx <= 1; dx++)
                    {
                        for (var dy = -1; dy <= 1; dy++)
                        {
                            move = new Shift(origin, BoardCoordinate.Get(x + dx, y + dy));
                            if (board.IsMoveValid(move, color))
                                yield return move;
                        }
                    }
                }
            }
        }

        public static void MakeMove(this Board board, IMove move, Color color)
        {
            if (!board.IsMoveValid(move, color))
                throw new ArgumentException();

            if (move is Rotate)
            {
                var rotate = (Rotate)move;
                board.GetSquare(rotate.Origin).Figure.Rotate(rotate.Rotation);
            }
            else
            {
                var shift = (Shift)move;

                var origin = board.GetSquare(shift.Origin);
                var destination = board.GetSquare(shift.Destination);

                if (destination.Figure != null)
                {
                    var temp = origin.Figure;
                    origin.Figure = destination.Figure;
                    destination.Figure = temp;
                }
                else
                {
                    destination.Figure = origin.Figure;
                    origin.Figure = null;
                }
            }
        }
    }
}
