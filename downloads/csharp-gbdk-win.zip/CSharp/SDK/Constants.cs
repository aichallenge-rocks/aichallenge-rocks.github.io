﻿using System;

namespace SDK
{
    public enum Color
    {
        White = 1,
        Red = 2,
        Neutral = 3
    };

    public enum Rotation
    {
        Clockwise = 0,
        Counterclockwise = 1
    };

    public enum Orientation
    {
        North = 1,
        East = 2,
        South = 3,
        West = 4
    };
}
