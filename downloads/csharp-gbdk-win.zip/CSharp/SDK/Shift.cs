﻿using System;

namespace SDK
{
    public class Shift : IMove
    {
        public readonly BoardCoordinate Origin, Destination;

        public Shift(BoardCoordinate origin, BoardCoordinate destination)
        {
            Origin = origin;
            Destination = destination;
        }

        public override string ToString()
        {
            return String.Empty + Origin + Destination;
        }
    }
}
