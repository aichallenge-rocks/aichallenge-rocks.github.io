﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    internal static class Constants
    {
        public const string StandardBoardPositon = "PH 74, S1 79, C1 44, C2 45, A1 73, A1 75, P1 23, P1 39, " +
            "P1 42, P1 72, P2 67, P4 32, P4 49, ph 05, s3 00, c1 35, c2 34, a3 04, a3 06, p2 30, p2 47, p3 07, p3 37, p3 40, p3 56, p4 12";
        public const string OrderedStandardBoardPositon = "s300,a304,ph05,a306,p307,p412,P123,p230,P432,c234,c135,p337,P139,p340,P142,C144,C245,p247,P449,p356,P267,P172,A173,PH74,A175,S179";
    }
}
