﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SDK;

namespace Test
{
    [TestClass]
    public class BoardTest
    {
        [TestMethod]
        public void IsOutOfBounds()
        {
            var board = new Board();

            Assert.IsTrue(board.IsOutOfBounds(BoardCoordinate.Get(-1, 0)));
            Assert.IsTrue(board.IsOutOfBounds(BoardCoordinate.Get(10, 0)));
            Assert.IsFalse(board.IsOutOfBounds(BoardCoordinate.Get(0, 0)));
        }
    }
}
