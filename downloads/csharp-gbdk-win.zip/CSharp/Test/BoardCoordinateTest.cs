﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SDK;

namespace Test
{
    [TestClass]
    public class BoardCoordinateTest
    {
        [TestMethod]
        public void Equality()
        {
            var bc1 = new BoardCoordinate(1, 2);
            var bc2 = new BoardCoordinate(1, 2);
            var bc3 = new BoardCoordinate(2, 1);

            Assert.AreEqual(bc1, bc1);
            Assert.AreEqual(bc2, bc2);
            Assert.AreEqual(bc1, bc2);
            Assert.AreNotEqual(bc1, bc3);
        }

        [TestMethod]
        public void Get()
        {
            Assert.AreEqual(BoardCoordinate.Get(2, 3), new BoardCoordinate(2, 3));
        }

        [TestMethod]
        public void ToStringTest()
        {
            var bc = BoardCoordinate.Get(1, 2);

            Assert.AreEqual(bc.ToString(), "21");
        }

        [TestMethod]
        public void Parse()
        {
            var bc = BoardCoordinate.Parse("32");

            Assert.AreEqual(new BoardCoordinate(2, 3), bc);
        }
    }
}
