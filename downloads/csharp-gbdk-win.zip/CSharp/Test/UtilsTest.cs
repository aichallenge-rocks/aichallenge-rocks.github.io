﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SDK;
using SDK.Figures;

namespace Test
{
    [TestClass]
    public class UtilsTest
    {
        [TestMethod]
        public void CreateBoardFromPosition()
        {
            var board = Utils.CreateBoardFromPosition("P3 42, ph 09");

            Assert.AreEqual(new Pyramid(Orientation.South, Color.White), board.GetSquare(BoardCoordinate.Get(2, 4)).Figure);
            Assert.AreEqual(new Pharaoh(Orientation.North, Color.Red), board.GetSquare(BoardCoordinate.Get(9, 0)).Figure);
            Assert.IsNull(board.GetSquare(BoardCoordinate.Get(4, 2)).Figure);
        }

        [TestMethod]
        public void CreateBoardFromPosition_StandardPosition()
        {
            var board = Utils.CreateBoardFromPosition(Constants.StandardBoardPositon);

            Action<int, int, Figure> checkFigure = delegate(int x, int y, Figure figure)
            {
                Assert.AreEqual(board.GetSquare(BoardCoordinate.Get(x, y)).Figure, figure);
            };

            checkFigure(4, 7, new Pharaoh(Orientation.North, Color.White));
            checkFigure(4, 7, new Pharaoh(Orientation.North, Color.White));
            checkFigure(9, 7, new Sphinx(Orientation.North, Color.White));
            checkFigure(4, 4, new Scarab(Orientation.North, Color.White));
            checkFigure(5, 4, new Scarab(Orientation.East, Color.White));
            checkFigure(3, 7, new Anubis(Orientation.North, Color.White));
            checkFigure(5, 7, new Anubis(Orientation.North, Color.White));
            checkFigure(3, 2, new Pyramid(Orientation.North, Color.White));
            checkFigure(9, 3, new Pyramid(Orientation.North, Color.White));
            checkFigure(2, 4, new Pyramid(Orientation.North, Color.White));
            checkFigure(2, 7, new Pyramid(Orientation.North, Color.White));
            checkFigure(7, 6, new Pyramid(Orientation.East, Color.White));
            checkFigure(2, 3, new Pyramid(Orientation.West, Color.White));
            checkFigure(9, 4, new Pyramid(Orientation.West, Color.White));
            checkFigure(5, 0, new Pharaoh(Orientation.North, Color.Red));
            checkFigure(0, 0, new Sphinx(Orientation.South, Color.Red));
            checkFigure(5, 3, new Scarab(Orientation.North, Color.Red));
            checkFigure(4, 3, new Scarab(Orientation.East, Color.Red));
            checkFigure(4, 0, new Anubis(Orientation.South, Color.Red));
            checkFigure(6, 0, new Anubis(Orientation.South, Color.Red));
            checkFigure(0, 3, new Pyramid(Orientation.East, Color.Red));
            checkFigure(7, 4, new Pyramid(Orientation.East, Color.Red));
            checkFigure(7, 0, new Pyramid(Orientation.South, Color.Red));
            checkFigure(7, 3, new Pyramid(Orientation.South, Color.Red));
            checkFigure(0, 4, new Pyramid(Orientation.South, Color.Red));
            checkFigure(6, 5, new Pyramid(Orientation.South, Color.Red));
            checkFigure(2, 1, new Pyramid(Orientation.West, Color.Red));
        }
    }
}
