﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SDK;
using System.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Test
{
    [TestClass]
    public class OrientationExtensionsTest
    {
        [TestMethod]
        public void Reverse()
        {
            Assert.AreEqual<Orientation>(Orientation.North.Reverse(), Orientation.South);
            Assert.AreEqual<Orientation>(Orientation.East.Reverse(), Orientation.West);
            Assert.AreEqual<Orientation>(Orientation.South.Reverse(), Orientation.North);
            Assert.AreEqual<Orientation>(Orientation.West.Reverse(), Orientation.East);
        }

        [TestMethod]
        public void Clockwise()
        {
            Assert.AreEqual<Orientation>(Orientation.North.Clockwise(), Orientation.East);
            Assert.AreEqual<Orientation>(Orientation.East.Clockwise(), Orientation.South);
            Assert.AreEqual<Orientation>(Orientation.South.Clockwise(), Orientation.West);
            Assert.AreEqual<Orientation>(Orientation.West.Clockwise(), Orientation.North);
        }

        [TestMethod]
        public void Counterclockwise()
        {
            Assert.AreEqual<Orientation>(Orientation.North.Counterclockwise(), Orientation.West);
            Assert.AreEqual<Orientation>(Orientation.East.Counterclockwise(), Orientation.North);
            Assert.AreEqual<Orientation>(Orientation.South.Counterclockwise(), Orientation.East);
            Assert.AreEqual<Orientation>(Orientation.West.Counterclockwise(), Orientation.South);
        }
    }

    [TestClass]
    public class BoardExtensionsTest
    {
        [TestMethod]
        public void SerializeBoard_EmptyBoard()
        {
            var board = new Board();

            Assert.AreEqual(board.Serialize(), "");
        }

        [TestMethod]
        public void SerializeBoard_StandardBoard()
        {
            var board = Utils.CreateBoardFromPosition(Constants.StandardBoardPositon);

            Assert.AreEqual(board.Serialize(), Constants.OrderedStandardBoardPositon);
        }

        [TestMethod]
        public void GetFigureCoordinates()
        {
            var board = Utils.CreateBoardFromPosition("PH 42");
            var position = BoardCoordinate.Get(2, 4);
            var figure = board.GetSquare(position).Figure;

            Assert.AreEqual(position, board.GetFigureCoordinates(figure));
        }

        [TestMethod]
        public void GetFigureToBeKilledByLaser()
        {
            var board = Utils.CreateBoardFromPosition("PH 00");
            var pharaoh = board.GetSquare(BoardCoordinate.Get(0, 0)).Figure;
            var figureToBeKilled = board.GetFigureToBeKilledByLaser(BoardCoordinate.Get(1, 0), Orientation.West);

            Assert.AreEqual(figureToBeKilled, pharaoh);
        }

        [TestMethod]
        public void GetFigureToBeKilledByLaser_ShouldReturnNull()
        {
            var board = Utils.CreateBoardFromPosition("PH 00");
            var figureToBeKilled = board.GetFigureToBeKilledByLaser(BoardCoordinate.Get(1, 0), Orientation.East);

            Assert.IsNull(figureToBeKilled);
        }

        [TestMethod]
        public void GetAvailableMoves()
        {
            var board = Utils.CreateBoardFromPosition("P1 11, p1 12");

            var actualMoves = board.GetAvailableMoves(Color.White).Select(move => {
                return move.ToString();
            });
            var expectedMoves = new List<string> {"11+1", "11-1", "1101", "1102", "1121", "1122"};

            Assert.IsTrue(actualMoves.OrderBy(x => x).SequenceEqual(expectedMoves.OrderBy(x => x)));
        }

        [TestMethod]
        public void GetFigureToBeKilledBySphinx_ShouldReturnNull()
        {
            var board = Utils.CreateBoardFromPosition("S2 00, P4 02, c1 22, p2 20");

            Assert.IsNull(board.GetFigureToBeKilledBySphinx(Color.White));
        }

        [TestMethod]
        public void GetFigureToBeKilledBySphinx_ShouldReturnTheFirstPyramid()
        {
            var board = Utils.CreateBoardFromPosition("S2 00, P2 01, p2 02");

            Assert.AreEqual(board.GetFigureToBeKilledBySphinx(Color.White), board.GetSquare(BoardCoordinate.Get(1, 0)).Figure);
        }

        [TestMethod]
        public void GetFigureToBeKilledBySphinx_ShouldReturnThePyramid()
        {
            var board = Utils.CreateBoardFromPosition("S1 79, P2 49");

            Assert.AreEqual(board.GetFigureToBeKilledBySphinx(Color.White), board.GetSquare(BoardCoordinate.Get(9, 4)).Figure);
        }

        [TestMethod]
        public void MakeMove_ScarabSwap()
        {
            var board = Utils.CreateBoardFromPosition(Constants.StandardBoardPositon);
            var newBoard = Utils.CreateBoardFromPosition(Constants.StandardBoardPositon);
            newBoard.MakeMove(new Shift(BoardCoordinate.Get(4, 4), BoardCoordinate.Get(5, 5)), Color.White);

            Assert.AreEqual(newBoard.GetSquare(BoardCoordinate.Get(4, 4)).Figure, board.GetSquare(BoardCoordinate.Get(5, 5)).Figure);
            Assert.AreEqual(newBoard.GetSquare(BoardCoordinate.Get(5, 5)).Figure, board.GetSquare(BoardCoordinate.Get(4, 4)).Figure);
        }
    }
}
