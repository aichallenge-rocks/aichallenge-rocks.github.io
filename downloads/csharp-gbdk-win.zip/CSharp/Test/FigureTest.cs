﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SDK;
using SDK.Figures;

namespace Test
{
    [TestClass]
    public class FigureTest
    {
        [TestMethod]
        public void ToStringTest()
        {
            var anubis = new Anubis(Orientation.South, Color.Red);

            Assert.AreEqual(anubis.ToString(), "a3");
        }
    }
}
