package com.epam.sdk.move;

/**
 * Created by numitus on 11/11/14.
 */
public interface Move {
}
