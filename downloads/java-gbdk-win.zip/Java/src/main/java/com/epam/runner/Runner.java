package com.epam.runner;

import com.epam.bot.DefaultBot;
import com.epam.bot.UserBot;
import com.epam.sdk.Board;
import com.epam.sdk.Color;
import com.epam.sdk.GameState;
import com.epam.sdk.IBot;
import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.epam.sdk.Color.WHITE;


/**
 * This class run bot.
 */
public class Runner {
  private static final Logger LOG = LoggerFactory.getLogger(Runner.class);
    public static final Color USER_BOT_COLOR = WHITE;

    final List<IBot> bots = new ArrayList<>();
    final int botCount;
    int currentTurn = 0;

    Runner() {
        bots.add(new UserBot());
        bots.add(new DefaultBot());
        botCount = isLocaleMode() ? 2 : 1;
    }

	private boolean isLocaleMode() {
		String localMode = System.getenv("IS_IN_LOCAL_MODE");
		return localMode == null || Boolean.valueOf(localMode);
	}
	
    /**
     * Method switch bot, and build move from current bot.
     * This method runs camel.
     */
    @SuppressWarnings("unchecked")
    public String getMove(Exchange exchange) {
      Map<String, Object> body = (Map) exchange.getIn().getBody(); //Raw data from server
      GameState gameState = GameState.parse(body);

      Board board = gameState.getBoard();
      long start = System.currentTimeMillis();
      String currentMove = bots.get(currentTurn).nextMove( board, gameState.getColor());
      long end = System.currentTimeMillis();

      long maxMoveTime = isLocaleMode() ? Integer.MAX_VALUE : TimeUnit.SECONDS.toMillis( 4 );
      long calculatedTime = end - start;

      LOG.info("Elapsed time for move is {} ms. (max 4000 ms)", calculatedTime);

      if (calculatedTime > maxMoveTime){
        LOG.info( "[BOT MOVE TIMEOUT]" );
        System.exit(1);
      }

        //Choose other bot
        currentTurn = (currentTurn + 1) % botCount;
        return currentMove;

    }
}
