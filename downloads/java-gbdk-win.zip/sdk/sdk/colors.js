var colors = {
    White: 1,
    Red: 2,
    Neutral: 3
};

module.exports = colors;