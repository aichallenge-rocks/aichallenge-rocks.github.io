/**
 * Your bot logic should be in that single file
 * You should send it to game server
*/

var utils = require('./sdk/utils'),
    util = require('util');

function chooseRandom(array) {
    return array[Math.floor(Math.random() * array.length)];
};

function UserBot(){}

util._extend(UserBot.prototype, {
    getMove: function(board, myColor)
    {
        var moves = utils.getAvailableMoves(board, myColor);
        var move = chooseRandom(moves);

        console.log('[UserBot] color: ' + myColor + ' move: ' + move);
        return move;
    }
});

module.exports = UserBot;