#! /bin/bash
nodejs bin/localRunner.js