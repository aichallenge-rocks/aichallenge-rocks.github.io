var util = require('util'),
    config = require('./config'),
    utils = require('../sdk/utils'),
    colors = require('../sdk/colors'),
    UserBot = require('../UserBot'),
    DefaultBot = require('./DefaultBot');

function BotRunner(){
    this.currentTurn = config.localRunner.isInLocalMode && config.localRunner.userBotColor === colors.Red ? 1 : 0;
    this.bots = [
        new UserBot(),
        new DefaultBot()
    ];

    this.botCount = config.localRunner.isInLocalMode ? this.bots.length : 1;
}

util._extend(BotRunner.prototype, {
    getMove: function (boardNotation, botColor)
    {
        var board = utils.createBoardFromPosition(boardNotation);
		
		var start = process.hrtime();
        var move = this.bots[this.currentTurn++].getMove(board, botColor);
        var elapsed = process.hrtime(start);
		
		var maxMoveTime = config.localRunner.isInLocalMode ? 600000 : 4;
		var calculatedTime = elapsed[0] + elapsed[1] / 1000000000;
		
		if (calculatedTime > maxMoveTime){
		    console.log('[BOT MOVE TIMEOUT]');
			throw new Error('[BOT MOVE TIMEOUT]');
		}
		
		if (this.currentTurn >= this.botCount)
        {
            this.currentTurn = 0;
        }

        return move;
    }
});

module.exports = new BotRunner();