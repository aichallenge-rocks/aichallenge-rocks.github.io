var express = require('express'),
    router = express.Router(),
    runner = require('./Runner');

module.exports = router;

router.post('/move', function(req, res) {
    console.log('Game state: ' + req.body.board);

    var move = runner.getMove(req.body.board, req.body.color);
    res.send(move);
});
