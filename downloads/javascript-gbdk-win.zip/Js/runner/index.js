var express = require('express'),
    bodyParser = require('body-parser'),
    rest = require('restler'),
    config = require('./config'),
    colors = require('../sdk/colors');

module.exports = function() {
    var app = express();

    app.set('port', config.localRunner.port);
    app.use(bodyParser.json());
    app.use(require('./router'));

    app.listen(app.get('port'), function () {
        console.log('LocalRunner started on port: ' + app.get('port'));

        if (config.localRunner.isInLocalMode) {
            var localBots = [
                {
                    color: colors.White,
                    userId: config.localRunner.userBotColor === colors.White ? 1 : 2
                },
                {
                    color: colors.Red,
                    userId: config.localRunner.userBotColor === colors.Red ? 1 : 2
                }
            ];

            rest.postJson('http://' + config.gameEngineSvc.hostname + ':' + config.gameEngineSvc.port + '/api/game/start', localBots).on('success', function () {
                localBots.forEach(function (bot) {
                    sendBotReady(bot);
                });
            });
        }
        else {
            sendBotReady();
        }
    });
};

function sendBotReady(data)
{
    rest.postJson('http://' + config.gameEngineSvc.hostname + ':' + config.gameEngineSvc.port + '/api/bot/ready', data);
}