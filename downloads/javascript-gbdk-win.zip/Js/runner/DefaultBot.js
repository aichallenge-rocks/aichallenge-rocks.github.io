var utils = require('../sdk/utils'),
    Pharaoh = require('../sdk/figures/pharaoh'),
    colors = require('../sdk/colors'),
    util = require('util');

function DefaultBot(){}

util._extend(DefaultBot.prototype, {
    chooseRandom : function(array){
        return array[Math.floor(Math.random() * array.length)];
    },
    logMove: function (move) {
        console.log("[DefaultBot] color: " + this.myColor + " move: " + move);
        return move;
    },
    getMove: function(board, myColor) {
        this.myColor = myColor;
        
        var position = utils.serializeBoard(board);
        var bestMoves = [];
        var maxScore = -100000000;
        var scoreFunc = this.getMoveScore;
        utils.getAvailableMoves(board, myColor).forEach(function(move) {
            var score = scoreFunc(position, move, myColor);
            if (score > maxScore) {
               bestMoves = [];
               maxScore = score;
            }
            if (score == maxScore) {
               bestMoves.push(move);
            }
        });
        
        return this.logMove(this.chooseRandom(bestMoves));
    },
    getMoveScore : function(position, move, color) {

        function getKilledFigureScore(figure, color) {
           if (figure==null) return 0;
           var sign = (figure.color == color) ? -1 : 1;
           return figure instanceof Pharaoh ? sign * 1000 : sign * 10;
        }

        var opponentColor = (color == colors.Red ? colors.White : colors.Red);
        var board = utils.createBoardFromPosition(position);
        utils.makeMove(board, move);
        
        var opponentKilledFigure = utils.getFigureToBeKilledBySphinx(board, color);
        var myKilledFigure = utils.getFigureToBeKilledBySphinx(board, opponentColor);
        
        var score = getKilledFigureScore(opponentKilledFigure, color) + getKilledFigureScore(myKilledFigure, color);
        return score;
    },
});

module.exports = DefaultBot;