var colors = require('../sdk/colors');

var config = {
    gameEngineSvc: {
        port: process.env.GAME_ENGINE_PORT ? parseInt(process.env.GAME_ENGINE_PORT) : 8080,
        hostname: process.env.GAME_ENGINE_HOSTNAME || "localhost"
    },
    localRunner: {
        isInLocalMode: process.env.IS_IN_LOCAL_MODE ? /^1|true$/i.test(process.env.IS_IN_LOCAL_MODE) : true,
        port: process.env.PORT ? parseInt(process.env.PORT) : 8081,
        userBotColor: colors.White
    }
};

module.exports = config;